#include <string.h>
#include <omnetpp.h>

using namespace omnetpp;

class computer : public cSimpleModule
{
  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

Define_Module(computer);

void computer::initialize()
{

    if (strcmp("computer1", getName()) == 0) {
        cMessage *msg = new cMessage("testMsg");
        send(msg, "out");
    }
}

void computer::handleMessage(cMessage *msg)
{
    send(msg, "out");
}



