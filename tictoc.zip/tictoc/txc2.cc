    //
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003 Ahmet Sekercioglu
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <string.h>
    #include <omnetpp.h>

    using namespace omnetpp;

    /**
      * Nesta classe, adicionamos algumas mensagens de depuração ao Txc1.
      * Quando você executar a simulação no OMNeT ++ GUI Tkenv, a saída aparecerá
      * na janela de texto principal e você também poderá abrir janelas de saída
      * separadas para `tic 'e` toc'.
      */

    class Txc2 : public cSimpleModule
    {
      protected:
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Txc2);

    void Txc2::initialize()
    {
        if (strcmp("tic", getName()) == 0) {
            // O objeto `ev' funciona como `cout' em C ++.
            // O EV imprime o que Txc2 está fazendo.
            EV << "Envio de mensagem inicial\n";
            cMessage *msg = new cMessage("tictocMsg");
            send(msg, "out");
        }
    }

    void Txc2::handleMessage(cMessage *msg)
    {
        // msg->getName() é o nome do objeto msg, aqui será "tictocMsg".
        EV << "Mensagem recebida `" << msg->getName() << "', enviando novamente\n";
        send(msg, "out");
    }



