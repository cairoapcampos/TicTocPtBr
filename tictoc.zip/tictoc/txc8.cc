//
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>

    using namespace omnetpp;

    /**
    * Vamos dar um passo para trás e remover atrasos aleatórios do código.
    * Vamos deixar, no entanto, perder o pacote com uma pequena probabilidade.
    * E nós vamos fazer algo muito comum em redes de telecomunicações:
    * se o pacote não chegar dentro de um certo período, assumiremos que ele
    * foi perdido e criaremos outro. O tempo limite será tratado usando
    * (o que mais?) uma auto-mensagem.
     */
    class Tic8 : public cSimpleModule
    {
      private:
        simtime_t timeout;  // timeout
        cMessage *timeoutEvent;  // mantém ponteiro para o timeout da auto-mensagem

      public:
        Tic8();
        virtual ~Tic8();

      protected:
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Tic8);

    Tic8::Tic8()
    {
        timeoutEvent = nullptr;
    }

    Tic8::~Tic8()
    {
        cancelAndDelete(timeoutEvent);
    }

    void Tic8::initialize()
    {
        // Inicializa variáveis.
        timeout = 1.0;
        timeoutEvent = new cMessage("timeoutEvent");

        // Gerar e enviar mensagem inicial.
        EV << "Envio de mensagem inicial\n";
        cMessage *msg = new cMessage("tictocMsg");
        send(msg, "out");
        scheduleAt(simTime()+timeout, timeoutEvent);
    }

    void Tic8::handleMessage(cMessage *msg)
    {
        if (msg == timeoutEvent) {
            // Se recebermos o evento timeout, significa que o pacote não chegou
            // a tempo e nós temos que reenviá-lo.
            EV << "Timeout expirou, reenviando a mensagem e reiniciando o temporizador\n";
            cMessage *newMsg = new cMessage("tictocMsg");
            send(newMsg, "out");
            scheduleAt(simTime()+timeout, timeoutEvent);
        }
        else {  // mensagem chegou
                // Acknowledgement  recebido - apague a mensagem recebida
               // e cancele o evento de timeout.
            EV << "Temporizador cancelado.\n";
            cancelEvent(timeoutEvent);
            delete msg;

            // Pronto para enviar outro.
            cMessage *newMsg = new cMessage("tictocMsg");
            send(newMsg, "out");
            scheduleAt(simTime()+timeout, timeoutEvent);
        }
    }

    /**
     * Envia de volta um acknowledgement - ou não.
     */
    class Toc8 : public cSimpleModule
    {
      protected:
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Toc8);

    void Toc8::handleMessage(cMessage *msg) // Toc perde a mensagem para Tic reenviá-la.
    {
        if (uniform(0, 1) < 0.1) {
            EV << "\"Perdendo\" mensagem.\n";
            bubble("mensagem perdida");  // tornando a animação mais informativa...
            delete msg;
        }
        else {
            EV << "enviando de volta a mesma mensagem como acknowledgement.\n";
            send(msg, "out");
        }
    }



