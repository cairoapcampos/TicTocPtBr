//
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003 Ahmet Sekercioglu
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>

    using namespace omnetpp;

    /**
     * Vamos tornar isso mais interessante usando vários módulos (n) `tic ',
     * e conectando cada módulo a todos os outros. Por enquanto, vamos simplificar
     * o que eles fazem: o módulo 0 gera uma mensagem, e os outros mantêm-na em direções
     * aleatórias até chegar ao módulo 2.
     */
    class Txc12 : public cSimpleModule
    {
      protected:
        virtual void forwardMessage(cMessage *msg);
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Txc12);

    void Txc12::initialize()
    {
        if (getIndex() == 0) {
            // Inicialize o processo agendando a mensagem inicial como uma auto-mensagem.
            char msgname[20];
            sprintf(msgname, "tic-%d", getIndex());
            cMessage *msg = new cMessage(msgname);
            scheduleAt(0.0, msg);
        }
    }

    void Txc12::handleMessage(cMessage *msg)
    {
        if (getIndex() == 3) {
            // Mensagem chegou.
            EV << "Message " << msg << " arrived.\n";
            delete msg;
        }
        else {
            // Precisamos encaminhar a mensagem.
            forwardMessage(msg);
        }
    }

    void Txc12::forwardMessage(cMessage *msg)
    {
        // Neste exemplo, apenas selecionamos um gate aleatório para enviá-lo.
        // Nós desenhamos um número aleatório entre 0 e o tamanho do gate `gate [] '.
        int n = gateSize("gate");
        int k = intuniform(0, n-1);

        EV << "Forwarding de mensagem " << msg << " no gate[" << k << "]\n";
        // O sufixo $o e $i é usado para identificar o input/output de um gate de duas vias.
        send(msg, "gate$o", k);
    }


