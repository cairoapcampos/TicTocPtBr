//
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>

    using namespace omnetpp;

    /**
     * No modelo anterior, criamos outro pacote se precisássemos retransmitir.
     * Isto está OK porque o pacote não contém muito, mas na vida real é geralmente
     * mais prático manter uma cópia do pacote original para que possamos reenviá-lo
     * sem a necessidade de compilá-lo novamente.
     */
    class Tic9 : public cSimpleModule
    {
      private:
        simtime_t timeout;  // timeout
        cMessage *timeoutEvent;  // mantém o ponteiro para a auto-mensagem de timeout
        int seq;  // número de sequência da mensagem
        cMessage *message;  // mensagem que precisa ser reenviada no timeout

      public:
        Tic9();
        virtual ~Tic9();

      protected:
        virtual cMessage *generateNewMessage();
        virtual void sendCopyOf(cMessage *msg);
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Tic9);

    Tic9::Tic9()
    {
        timeoutEvent = message = nullptr;
    }

    Tic9::~Tic9()
    {
        cancelAndDelete(timeoutEvent);
        delete message;
    }

    void Tic9::initialize()
    {
        // Inicialize variáveis.
        seq = 0;
        timeout = 1.0;
        timeoutEvent = new cMessage("timeoutEvent");

        // Gerar e enviar mensagem inicial.
        EV << "Envio de mensagem inicial\n";
        message = generateNewMessage();
        sendCopyOf(message);
        scheduleAt(simTime()+timeout, timeoutEvent);
    }

    void Tic9::handleMessage(cMessage *msg)
    {
        if (msg == timeoutEvent) {
            // Se recebermos o evento timeout, significa que o
            // pacote não chegou a tempo e temos que reenviá-lo.
            EV << "Timeout expirou, enviando mensagem e reiniciando o temporizador\n";
            sendCopyOf(message);
            scheduleAt(simTime()+timeout, timeoutEvent);
        }
        else {  // mensagem chegou
                // Acknowledgement recebida!
            EV << "Recebido: " << msg->getName() << "\n";
            delete msg;

            // Exclua também a mensagem armazenada e cancele o evento de timeout.
            EV << "Temporizador cancelado.\n";
            cancelEvent(timeoutEvent);
            delete message;

            // Pronto para enviar outro.
            message = generateNewMessage();
            sendCopyOf(message);
            scheduleAt(simTime()+timeout, timeoutEvent);
        }
    }

    cMessage *Tic9::generateNewMessage()
    {
        // Gere uma mensagem com um nome diferente todas as vezes.
        char msgname[20];
        sprintf(msgname, "tic-%d", ++seq);
        cMessage *msg = new cMessage(msgname);
        return msg;
    }

    void Tic9::sendCopyOf(cMessage *msg)
    {
        // Duplicar mensagem e enviar a cópia.
        cMessage *copy = (cMessage *)msg->dup();
        send(copy, "out");
    }

    /**
     * Envia de volta um acknowledgement -- ou não.
     */
    class Toc9 : public cSimpleModule
    {
      protected:
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Toc9);

    void Toc9::handleMessage(cMessage *msg)
    {
        if (uniform(0, 1) < 0.1) {
            EV << "\"Perdendo\" mensagem " << msg << endl;
            bubble("message lost");
            delete msg;
        }
        else {
            EV << msg << " recebido, enviando de volta um acknowledgement.\n";
            delete msg;
            send(new cMessage("ack"), "out");
        }
    }


