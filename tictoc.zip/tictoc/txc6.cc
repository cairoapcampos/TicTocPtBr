//
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>

    using namespace omnetpp;

    /**
    * Nos modelos anteriores, `tic 'e` toc' enviaram imediatamente a mensagem recebida.
    * Aqui vamos adicionar um pouco de tempo: tic e toc manterão a mensagem por 1 segundo simulado
    * antes de enviá-la de volta. No OMNeT ++, esse tempo é alcançado pelo módulo que envia uma mensagem
    *  para si mesmo. Tais mensagens são chamadas de auto-mensagens (mas apenas pelo modo como são usadas,
    *  caso contrário, são mensagens completamente comuns) ou eventos. As auto-mensagens podem ser
    *  "enviadas" com a função scheduleAt () e você pode especificar quando devem retornar ao módulo.
    *
    * Deixamos de fora o contador, para manter o código-fonte pequeno.
    */
    class Txc6 : public cSimpleModule
    {
      private:
        cMessage *event;  // ponteiro para o objeto de evento que vamos usar para o tempo
                          // variável para lembrar a mensagem até que a enviemos de volta
        cMessage *tictocMsg;

      public:
        Txc6();
        virtual ~Txc6();

      protected:
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Txc6);

    Txc6::Txc6()
    {

        // Configure o ponteiro para nullptr, para que o destructor
        // não trave mesmo se initialize () não for chamado por causa
        // de um erro de tempo de execução ou cancelamento do usuário
        // durante o processo de inicialização.
        event = tictocMsg = nullptr;
    }

    Txc6::~Txc6()
    {
        // Descartar os objetos alocados dinamicamente
        cancelAndDelete(event);
        delete tictocMsg;
    }

    void Txc6::initialize()
    {
        // Cria o objeto de evento que usaremos para o tempo - qualquer mensagem comum.
        event = new cMessage("event");

        // Nenhuma mensagem do tictoc ainda.
        tictocMsg = nullptr;

        if (strcmp("tic", getName()) == 0) {
            // Não começamos de imediato, mas em vez disso enviamos uma mensagem para nós
            // mesmos (uma "auto-mensagem") - faremos o primeiro envio quando chegar de
            // volta a nós, no tempo simulado de t = 5.0s.
            EV << "Agendamento primeiro enviar para t = 5,0s\n";
            tictocMsg = new cMessage("tictocMsg");
            scheduleAt(5.0, event);
        }
    }

    void Txc6::handleMessage(cMessage *msg)
    {
        // Existem várias maneiras de distinguir mensagens, por exemplo, por tipo de mensagem
        // (um atributo int de cMessage) ou por classe usando dynamic_cast (desde que você subclasse de cMessage).
        // Neste código, apenas verificamos se reconhecemos o ponteiro, o qual (se viável)
        // é o método mais fácil e rápido.
        if (msg == event) {
            // A auto-mensagem chegou, então podemos enviar tictocMsg e anular seu ponteiro para
            // que ele não nos confunda mais tarde.
            EV << "O período de espera acabou, enviando a mensagem de volta\n";
            send(tictocMsg, "out");
            tictocMsg = nullptr;
        }
        else {
            // Se a mensagem que recebemos não for nossa auto-mensagem, então deve ser a mensagem
            // tic-toc recebida do nosso parceiro. Lembramos seu ponteiro na variável tictocMsg e,
            // em seguida, planejamos nossa auto-mensagem para nos retornar em 1s de tempo simulado.
            EV << "A mensagem chegou, iniciando a espera de 1 sec...\n";
            tictocMsg = msg;
            scheduleAt(simTime()+1.0, event);
        }
    }




