//
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>

    using namespace omnetpp;

    /**
     * Nesta etapa, você aprenderá como adicionar parâmetros de entrada à simulação:
     * vamos transformar o "número mágico" 10 em um parâmetro.
     */

    class Txc4 : public cSimpleModule
    {
      private:
        int counter;

      protected:
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Txc4);

    void Txc4::initialize()
    {
        // Inicialize o contador com o parâmetro do módulo "limit",
        // declarado no arquivo NED (tictoc4.ned).
        counter = par("limit");

        // não dependemos mais do nome do módulo para decidir
        // se enviaremos uma mensagem inicial
        if (par("sendMsgOnInit").boolValue() == true) {
            EV << "Enviando mensagem inicial\n";
            cMessage *msg = new cMessage("tictocMsg");
            send(msg, "out");
        }
    }

    void Txc4::handleMessage(cMessage *msg)
    {
        counter--;
        if (counter == 0) {
            EV << "O contador de " << getName() << " chegou a zero, excluindo mensagem\n";
            delete msg;
        }
        else {
            EV << "O contador de " << getName() << " é " << counter << ", enviando de volta a mensagem\n";
            send(msg, "out");
        }
    }
