//
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003 Ahmet Sekercioglu
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>
    #include "tictoc16_m.h"

    using namespace omnetpp;

    /**
     * * O principal problema com a etapa anterior é que devemos modificar
     * o código do modelo, se quisermos alterar quais estatísticas são coletadas.
     * O cálculo estatístico é profundamente inserido no código do modelo,
     * que é difícil de modificar e entender.
     *
     * O OMNeT ++ 4.1 fornece um mecanismo diferente chamado 'sinais' que podemos usar
     * para coletar estatísticas. Primeiro temos que identificar os eventos em que o estado
     * do modelo muda. Podemos emitir sinais nesses pontos que carregam o valor das variáveis
     * de estado escolhidas. Desta forma, o código C ++ apenas emite sinais, mas como esses sinais
     * são processados são determinados apenas pelos ouvintes que estão ligados a eles.
     *
     * Os sinais que o modelo emite e os ouvintes que os processam podem ser definidos
     * no arquivo NED usando a propriedade 'signal' e 'statistic'.
     *
     * Reuniremos as mesmas estatísticas da etapa anterior, mas observe que não precisaremos
     * de nenhuma variável de membro particular para calcular esses valores. Nós usaremos apenas
     * um único sinal que é emitido quando uma mensagem chega e carrega a contagem de pontos na mensagem.
     */
    class Txc16 : public cSimpleModule
    {
      private:
        simsignal_t arrivalSignal;

      protected:
        virtual TicTocMsg16 *generateMessage();
        virtual void forwardMessage(TicTocMsg16 *msg);
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Txc16);

    void Txc16::initialize()
    {
        arrivalSignal = registerSignal("arrival");
        // Módulo 0 envia a primeira mensagem
        if (getIndex() == 0) {
            // Inicialize o processo agendando a mensagem inicial como uma auto-mensagem.
            TicTocMsg16 *msg = generateMessage();
            scheduleAt(0.0, msg);
        }
    }

    void Txc16::handleMessage(cMessage *msg)
    {
        TicTocMsg16 *ttmsg = check_and_cast<TicTocMsg16 *>(msg);

        if (ttmsg->getDestination() == getIndex()) {
            // Mensagem chegou
            int hopcount = ttmsg->getHopCount();
            // envia um sinal
            emit(arrivalSignal, hopcount);

            EV << "Mensagem " << ttmsg << " chegou depois " << hopcount << " saltos.\n";
            bubble("CHEGOU, começando uma nova!");

            delete ttmsg;

            // Gere outro.
            EV << "Gerando outra mensagem: ";
            TicTocMsg16 *newmsg = generateMessage();
            EV << newmsg << endl;
            forwardMessage(newmsg);
        }
        else {
            // Precisamos encaminhar a mensagem.
            forwardMessage(ttmsg);
        }
    }

    TicTocMsg16 *Txc16::generateMessage()
    {
        // Produzir endereços de origem e destino.
        int src = getIndex();
        int n = getVectorSize();
        int dest = intuniform(0, n-2);
        if (dest >= src)
            dest++;

        char msgname[20];
        sprintf(msgname, "tic-%d-to-%d", src, dest);

        // Criar um objeto de mensagem e definir o campo de origem e destino.
        TicTocMsg16 *msg = new TicTocMsg16(msgname);
        msg->setSource(src);
        msg->setDestination(dest);
        return msg;
    }

    void Txc16::forwardMessage(TicTocMsg16 *msg)
    {
        // Incrementar contagem de saltos.
        msg->setHopCount(msg->getHopCount()+1);

        // O mesmo roteamento de antes: portão aleatório.
        int n = gateSize("gate");
        int k = intuniform(0, n-1);

        EV << "Forwarding de mensagem " << msg << " no gate[" << k << "]\n";
        send(msg, "gate$o", k);
    }

