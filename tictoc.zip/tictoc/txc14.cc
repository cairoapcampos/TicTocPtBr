//
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003 Ahmet Sekercioglu
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>
    #include "tictoc14_m.h"

    using namespace omnetpp;

   // using std::cout;
   // using std::endl;

    /**
     * Nesta etapa, rastreamos quantas mensagens enviamos e recebemos
     * e as exibimos acima do ícone.
     */
    class Txc14 : public cSimpleModule
    {
      private:
        long numSent;
        long numReceived;

      protected:
        virtual TicTocMsg14 *generateMessage();
        virtual void forwardMessage(TicTocMsg14 *msg);
        virtual void refreshDisplay() const override;

        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Txc14);

    void Txc14::initialize()
    {
        // Inicializar variáveis
        numSent = 0;
        numReceived = 0;
        WATCH(numSent);
        WATCH(numReceived);

        // // Módulo 0 envia a primeira mensagem
        if (getIndex() == 0) {
            // Inicialize o processo agendando a mensagem inicial como uma auto-mensagem.
            TicTocMsg14 *msg = generateMessage();
            numSent++;
            scheduleAt(0.0, msg);
        }
    }

    void Txc14::handleMessage(cMessage *msg)
    {
        TicTocMsg14 *ttmsg = check_and_cast<TicTocMsg14 *>(msg);

        if (ttmsg->getDestination() == getIndex()) {
            // Mensagem chegou
            int hopcount = ttmsg->getHopCount();
            EV << "Mensagem " << ttmsg << " chegou depois " << hopcount << " saltos.\n";
            numReceived++;
            delete ttmsg;
            bubble("CHEGOU, começando um novo!");

            // Generate another one.
            EV << "Gerando outra mensagem: ";
            TicTocMsg14 *newmsg = generateMessage();
            EV << newmsg << endl;
            forwardMessage(newmsg);
            numSent++;
        }
        else {
            // Precisamos encaminhar a mensagem.
            forwardMessage(ttmsg);
        }
    }

    TicTocMsg14 *Txc14::generateMessage()
    {
        // Produza endereços de origem e destino.
        int src = getIndex();  // nosso índice de módulo
        int n = getVectorSize();  // tamanho do vetor do módulo
        int dest = intuniform(0, n-2);
        if (dest >= src)
            dest++;

        char msgname[20];
        sprintf(msgname, "tic-%d-to-%d", src, dest);

        // Criar um objeto de mensagem e definir o campo de origem e destino.
        TicTocMsg14 *msg = new TicTocMsg14(msgname);
        msg->setSource(src);
        msg->setDestination(dest);
        return msg;
    }

    void Txc14::forwardMessage(TicTocMsg14 *msg)
    {
        // Incrementar contagem de saltos.
        msg->setHopCount(msg->getHopCount()+1);

        // O mesmo roteamento de antes: gate aleatório.
        int n = gateSize("gate");
        int k = intuniform(0, n-1);

        EV << "Forwarding de mensagem " << msg << " no gate[" << k << "]\n";
        send(msg, "gate$o", k);
       // cout << "Mensagem teste: " << msg << endl;
    }

    void Txc14::refreshDisplay() const
    {
        char buf[40];
        sprintf(buf, "rcvd: %ld sent: %ld", numReceived, numSent);
        getDisplayString().setTagArg("t", 0, buf);
    }

