#include <string.h>
#include <omnetpp.h>

    using namespace omnetpp;

    /**
     * Derive a classe Txc1 do cSimpleModule.
     * Na rede Tictoc1, os módulos `tic 'e` toc' são objetos Txc1,
     * criados pelo OMNeT ++ no início da simulação.
     */

    class Txc1 : public cSimpleModule // o módulo simples Txc1 do arquivo NED é representado pela classe C++ Txc1.
    {
      protected:
        // A seguinte função virtual redefinida contém o algoritmo.
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    // O modulo de subclasse Txc1 precisa ser registrada com o OMNeT ++.
    Define_Module(Txc1);

    void Txc1::initialize() // initialize é um método de cSimpleModule
    {

        // Initialize é chamado no início da simulação.
        // Para inicializar o processo tic-toc-tic-toc,
       // um dos módulos precisa enviar a primeira mensagem. Que inicia é o nó "tic".

        // Eu sou Tic ou Toc?
        if (strcmp("tic", getName()) == 0) {
            // cria e envia a primeira mensagem no gate "out".
            // "tictocMsg" é uma string arbitrária que será o nome do objeto de mensagem.

           // cMessage *msg;
           // send(msg, "out"); // sem inicialização! (Falha (Crashes))

            cMessage *msg = new cMessage("tictocMsg"); // Criação do objeto de mensagem "cMessage".
            send(msg, "out");
        }
    }

    void Txc1::handleMessage(cMessage *msg) // handleMessage é um método de cSimpleModule.
    {
        // O método handleMessage () é chamado sempre que uma mensagem chega ao módulo.
        // Aqui, nós apenas enviamos para o outro módulo, através do gate 'out'.
        // Como o `tic 'e o` toc' fazem o mesmo, a mensagem irá saltar entre os dois.
        send(msg, "out"); // Envio de mensagem.
        // send(msg, "out"); // Isto deve causar um erro - Teste de Debug
    }



