//
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>

    using namespace omnetpp;

    /**
     * Nesta etapa, vamos introduzir números aleatórios. Alteramos o atraso de 1s para um valor aleatório
     * que pode ser definido no arquivo NED ou no omnetpp.ini. Além disso, "perderemos" (será excluido) o pacote
     * com uma pequena probabilidade.
     */
    class Txc7 : public cSimpleModule
    {
      private:
        cMessage *event;
        cMessage *tictocMsg;

      public:
        Txc7();
        virtual ~Txc7();

      protected:
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Txc7);

    Txc7::Txc7()
    {
        event = tictocMsg = nullptr;
    }

    Txc7::~Txc7()
    {
        cancelAndDelete(event);
        delete tictocMsg;
    }

    void Txc7::initialize()
    {
        event = new cMessage("event");
        tictocMsg = nullptr;

        if (strcmp("tic", getName()) == 0) {
            EV << "Agendamento primeiro enviar para t = 5,0s\n";
            scheduleAt(5.0, event);
            tictocMsg = new cMessage("tictocMsg");
        }
    }

    void Txc7::handleMessage(cMessage *msg)
    {
        if (msg == event) {
            EV << "O período de espera acabou, enviando a mensagem de volta\n";
            send(tictocMsg, "out");
            tictocMsg = nullptr;
        }
        else {
            // "Perder" a mensagem com probabilidade 0.1:
            if (uniform(0, 1) < 0.1) {
                EV << "\"Perdendo\" mensagem\n";
                delete msg;
            }
            else {
                // O parâmetro do módulo "delayTime" pode ser configurado para valores como
                // "exponencial (5)" (tictoc7.ned, omnetpp.ini), e então aqui teremos um atraso
                // diferente a cada vez.
                simtime_t delay = par("delayTime");

                EV << "A mensagem chegou, iniciando a espera " << delay << " secs...\n";
                tictocMsg = msg;
                scheduleAt(simTime()+delay, event);
            }
        }
    }




