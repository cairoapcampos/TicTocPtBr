     //
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003 Ahmet Sekercioglu
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>

    using namespace omnetpp;

    /**
     * Vamos tornar isso mais interessante usando vários módulos (n) `tic ',
     * e conectando cada módulo a todos os outros. Por enquanto, vamos simplificar
     * o que eles fazem: o módulo 0 gera uma mensagem, e os outros mantêm-na em direções
     * aleatórias até chegar ao módulo 3.
     */
    class Txc10 : public cSimpleModule
    {
      protected:
        virtual void forwardMessage(cMessage *msg);
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Txc10);

    void Txc10::initialize()
    {
        if (getIndex() == 0) {
            // Inicialize o processo agendando a mensagem inicial como uma auto-mensagem.
            char msgname[20];
            sprintf(msgname, "tic-%d", getIndex());
            cMessage *msg = new cMessage(msgname);
            scheduleAt(0.0, msg);
        }
    }

    void Txc10::handleMessage(cMessage *msg)
    {
        if (getIndex() == 3) {
            // Mensagem chegou.
            EV << "Mensagem " << msg << " chegou.\n";
            delete msg;
        }
        else {
            // Precisamos encaminhar a mensagem.
            forwardMessage(msg);
        }
    }

    void Txc10::forwardMessage(cMessage *msg)
    {
        // Neste exemplo, apenas selecionamos um gate aleatório para enviá-lo.
        // Nós desenhamos um número aleatório entre 0 e o tamanho do gate `out [] '.
        int n = gateSize("out");
        int k = intuniform(0, n-1);

        EV << "Mensagem de Forwarding " << msg << " na porta out[" << k << "]\n";
        send(msg, "out", k);
    }




