//
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003 Ahmet Sekercioglu
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>
    #include "tictoc15_m.h"

    using namespace omnetpp;

    /**
     * Este modelo é excitante o suficiente para que possamos coletar algumas estatísticas.
     * Vamos gravar nos vetores de saída a contagem de saltos de cada mensagem na chegada.
     * Os vetores de saída são gravados no arquivo omnetpp.vec e podem ser visualizados com o programa Plove.
     *
     * Também coletamos estatísticas básicas (min, max, mean, std.dev.) E histograma sobre a contagem de saltos
     * que serão impressas no final da simulação.
     */
    class Txc15 : public cSimpleModule
    {
      private:
        long numSent;
        long numReceived;
        cLongHistogram hopCountStats; // objeto adicionado que calcula média e outros valores
        cOutVector hopCountVector; // objeto de vetor de saida que registra os dados em Tictoc15-#0.vec

      protected:
        virtual TicTocMsg15 *generateMessage();
        virtual void forwardMessage(TicTocMsg15 *msg);
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;

        // A função finish () é chamada pelo OMNeT ++ no final da simulação:
        virtual void finish() override;
    };

    Define_Module(Txc15);

    void Txc15::initialize()
    {
        // Inicializar variáveis
        numSent = 0;
        numReceived = 0;
        WATCH(numSent);
        WATCH(numReceived);

        hopCountStats.setName("hopCountStats");
        hopCountStats.setRangeAutoUpper(0, 10, 1.5);
        hopCountVector.setName("HopCount");

        // Módulo 0 envia a primeira mensagem
        if (getIndex() == 0) {
            // Inicializa o processo agendando a mensagem inicial como uma alto-mensagem.
            TicTocMsg15 *msg = generateMessage();
            scheduleAt(0.0, msg);
        }
    }

    void Txc15::handleMessage(cMessage *msg)
    {
        TicTocMsg15 *ttmsg = check_and_cast<TicTocMsg15 *>(msg);

        if (ttmsg->getDestination() == getIndex()) {
            // Mensagem chegou
            int hopcount = ttmsg->getHopCount();
            EV << "Mensagem " << ttmsg << " chegou depois " << hopcount << " saltos.\n";
            bubble("CHEGOU, iniciando um novo!");

            // atualiza estatísticas.
            numReceived++;
            hopCountVector.record(hopcount);
            hopCountStats.collect(hopcount);

            delete ttmsg;

            // Gere outro.
            EV << "Gerando outra mensagem: ";
            TicTocMsg15 *newmsg = generateMessage();
            EV << newmsg << endl;
            forwardMessage(newmsg);
            numSent++;
        }
        else {
            // Precisamos encaminhar a mensagem.
            forwardMessage(ttmsg);
        }
    }

    TicTocMsg15 *Txc15::generateMessage()
    {
        // Produzir endereços de origem e destino.
        int src = getIndex();
        int n = getVectorSize();
        int dest = intuniform(0, n-2);
        if (dest >= src)
            dest++;

        char msgname[20];
        sprintf(msgname, "tic-%d-to-%d", src, dest);

        // Criar um objeto de mensagem e definir o campo de origem e destino.
        TicTocMsg15 *msg = new TicTocMsg15(msgname);
        msg->setSource(src);
        msg->setDestination(dest);
        return msg;
    }

    void Txc15::forwardMessage(TicTocMsg15 *msg)
    {
        // Increment hop count.
        msg->setHopCount(msg->getHopCount()+1);

        // Incrementar contagem de saltos.
        int n = gateSize("gate");
        int k = intuniform(0, n-1);

        EV << "Forwarding de mesagem " << msg << " no gate[" << k << "]\n";
        send(msg, "gate$o", k);
    }

    void Txc15::finish()
    {
        // Essa função é chamada pelo OMNeT ++ no final da simulação.
        EV << "Enviei:     " << numSent << endl;
        EV << "Recebida: " << numReceived << endl;
        EV << "Contagem de saltos, min:    " << hopCountStats.getMin() << endl;
        EV << "Contagem de saltos, max:    " << hopCountStats.getMax() << endl;
        EV << "Contagem de saltos, medio:   " << hopCountStats.getMean() << endl;
        EV << "Contagem de saltos, stddev: " << hopCountStats.getStddev() << endl;

        recordScalar("#sent", numSent);
        recordScalar("#received", numReceived);

        hopCountStats.recordAs("hop count");
    }





