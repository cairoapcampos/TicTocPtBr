//
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>

    using namespace omnetpp;

    /**
     * Nesta classe, adicionamos um contador e excluímos a mensagem após dez trocas.
     */
    class Txc3 : public cSimpleModule
    {
      private:
        int counter;  // Observe o contador aqui

      protected:
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Txc3);

    void Txc3::initialize()
    {
        // Inicializa o contador com o valor dez que será decrementado.
        // A mensagem será excluida quando o contador chegar ao valor zero.
        counter = 10;

        // A instrução WATCH () abaixo permitirá que você examine a variável no Tkenv (Interface gráfica).
        // Depois de fazer alguns passos na simulação, clique duas vezes em `tic 'ou` toc',
        // selecione a aba Contents na caixa de diálogo que aparece, e você encontrará "counter" na lista.

        WATCH(counter);

        if (strcmp("tic", getName()) == 0) {
            EV << "Enviando mensagem inicial\n";
            cMessage *msg = new cMessage("tictocMsg");
            send(msg, "out");
        }
    }

    void Txc3::handleMessage(cMessage *msg)
    {
        // Incrementar contador e verificar valor.
        counter--;
        if (counter == 0) {
            // Se o contador for zero, apague a mensagem. Se você executar o modelo,
            // verá que a simulação será interrompida neste ponto com a mensagem "no more events".
            EV << "O contador de " << getName() << " chegou a zero, excluindo mensagem\n";
            delete msg;
        }
        else {
            EV << "O contador de " << getName() << " é " << counter << ", enviando de volta a mensagem\n";
            send(msg, "out");
        }
    }





