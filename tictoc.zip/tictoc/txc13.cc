//
    // This file is part of an OMNeT++/OMNEST simulation example.
    //
    // Copyright (C) 2003 Ahmet Sekercioglu
    // Copyright (C) 2003-2015 Andras Varga
    //
    // This file is distributed WITHOUT ANY WARRANTY. See the file
    // `license' for details on this and other legal matters.
    //

    #include <stdio.h>
    #include <string.h>
    #include <omnetpp.h>

    using namespace omnetpp;

    // Incluir um arquivo gerado: o arquivo de cabeçalho criado a partir de tictoc13.msg.
    // Ele contém a definição da classe TictocMsg10, derivada de cMessage.
    #include "tictoc13_m.h"

    /**
     * Nesta etapa, o endereço de destino não é mais o nó 2 - nós desenhamos um destino aleatório
     * e adicionaremos o endereço de destino à mensagem.
     *
     * A melhor maneira é subclassificar cMensage e adicionar destino como um membro de dados.
     * Codificar manualmente a classe da mensagem é geralmente cansativo, pois contém muito código clichê,
     * então deixamos o OMNeT ++ gerar a classe para nós. A especificação da classe da mensagem está em
     * tictoc13.msg - tictoc13_m.h e tictoc13_m.cc serão gerados a partir desse arquivo automaticamente.
     *
     * Para tornar o modelo mais longo, depois que uma mensagem chegar ao seu destino,
     * o nó de destino gerará outra mensagem
     * com um endereço de destino aleatório e assim por diante.
     */
    class Txc13 : public cSimpleModule
    {
      protected:
        virtual TicTocMsg13 *generateMessage();
        virtual void forwardMessage(TicTocMsg13 *msg);
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };

    Define_Module(Txc13);

    void Txc13::initialize()
    {
        // Módulo 0 envia a primeira mensagem
        if (getIndex() == 0) {
            // Inicialize o processo agendando a mensagem inicial como uma auto-mensagem.
            TicTocMsg13 *msg = generateMessage();
            scheduleAt(0.0, msg);
        }
    }

    void Txc13::handleMessage(cMessage *msg)
    {
        TicTocMsg13 *ttmsg = check_and_cast<TicTocMsg13 *>(msg);

        if (ttmsg->getDestination() == getIndex()) {
            // Message arrived.
            EV << "Messagem " << ttmsg << " chegou depois " << ttmsg->getHopCount() << " saltos.\n";
            bubble("CHEGOU, iniciando um novo!");
            delete ttmsg;

            // Gere outro.
            EV << "Gerando outra mensagem: ";
            TicTocMsg13 *newmsg = generateMessage();
            EV << newmsg << endl;
            forwardMessage(newmsg);
        }
        else {
            // Precisamos encaminhar a mensagem.
            forwardMessage(ttmsg);
        }
    }

    TicTocMsg13 *Txc13::generateMessage()
    {
        // Produza endereços de origem e destino.
        int src = getIndex();  // nosso índice de módulo
        int n = getVectorSize();  // tamanho do vetor do módulo
        int dest = intuniform(0, n-2);
        if (dest >= src)
            dest++;

        char msgname[20];
        sprintf(msgname, "tic-%d-to-%d", src, dest);

        // Criar um objeto de mensagem e definir o campo de origem e destino.
        TicTocMsg13 *msg = new TicTocMsg13(msgname);
        msg->setSource(src);
        msg->setDestination(dest);
        return msg;
    }

    void Txc13::forwardMessage(TicTocMsg13 *msg)
    {
        // Incrementar contagem de saltos.
        msg->setHopCount(msg->getHopCount()+1);

        // O mesmo roteamento de antes: gate aleatório.
        int n = gateSize("gate");
        int k = intuniform(0, n-1);

        EV << "Mensagem de encaminhamento " << msg << " no gate[" << k << "]\n";
        send(msg, "gate$o", k);
    }



